<?php
defined('_JEXEC') or die("Access Deny");
echo "<h4>welcome to my frontend</h4>";

